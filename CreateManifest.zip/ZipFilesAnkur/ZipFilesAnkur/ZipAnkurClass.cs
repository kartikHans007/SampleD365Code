using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using System;
using System.Threading;
using ICSharpCode.SharpZipLib.Zip;
using ICSharpCode.SharpZipLib.Core;
using ICSharpCode.SharpZipLib.GZip;
using Microsoft.WindowsAzure.Storage;
using Microsoft.WindowsAzure.Storage.Blob;
using System.IO.Compression;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace ZipFilesAnkur
{
    public static class ZipAnkurClass
    {
        [FunctionName("ankurZip")]
        public static IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)]HttpRequest req, TraceWriter log)
        {
         

            log.Info("Zip creation");
            string requestBody = new StreamReader(req.Body).ReadToEnd();
            var input = JsonConvert.DeserializeObject<ZipContract>(requestBody);


            Task<string> t = ZipBlob2Blob(input);
            t.Wait();

            return new OkObjectResult(t.Result);
        }



        static async Task<string> ZipBlob2Blob(ZipContract _zipContract)
        {
            string ret;
            try
            { 
                string storageAccount_connectionString = "DefaultEndpointsProtocol=https;AccountName=ankurpgp;AccountKey=S1KPk8s7I/yKTL6ahpEdYFk3luzhzG0i5IQ5uxBdHW+Ck2q3Mj9le0lprsFUrDkzWAa7nF+gP6TjusJQciYgBA==;EndpointSuffix=core.windows.net";
                CloudStorageAccount storageAccount = CloudStorageAccount.Parse(storageAccount_connectionString);
                CloudBlobClient blobClient = storageAccount.CreateCloudBlobClient();
                CloudBlobContainer container = blobClient.GetContainerReference(_zipContract.packageFileContainerName);

                CloudBlobContainer outcontainer = blobClient.GetContainerReference(_zipContract.outputContainerName);
                CloudBlockBlob zipblob = outcontainer.GetBlockBlobReference("CustomerGroup.zip");
                CloudBlobStream zipstream = await zipblob.OpenWriteAsync();

                using (ZipArchive zipArchive = new ZipArchive(zipstream, ZipArchiveMode.Create))
                {
                    CloudBlobDirectory dira = container.GetDirectoryReference(string.Empty);
                    BlobResultSegment rootDirFolders = dira.ListBlobsSegmentedAsync(true, BlobListingDetails.Metadata, null, null, null, null).Result;
                    foreach (IListBlobItem blob in rootDirFolders.Results)
                    {
                        Console.WriteLine(blob.Uri.ToString());
                        CloudBlockBlob cbb = (CloudBlockBlob)blob;
                        using (Stream blobstream = await cbb.OpenReadAsync())
                        {
                            ZipArchiveEntry entry = zipArchive.CreateEntry(cbb.Name, CompressionLevel.Optimal);
                            using (var innerFile = entry.Open())
                            {
                                await blobstream.CopyToAsync(innerFile);
                            }
                        }
                    }


                    CloudBlobContainer containerCustomerFile = blobClient.GetContainerReference(_zipContract.inputContainerName);
                    CloudBlockBlob containerCustomerblob = containerCustomerFile.GetBlockBlobReference(_zipContract.fileName);
                    Stream fileStreamCustomerBlob = await containerCustomerblob.OpenReadAsync();

                    ZipArchiveEntry entryCust = zipArchive.CreateEntry(containerCustomerblob.Name, CompressionLevel.Optimal);
                    using (var innerFile = entryCust.Open())
                    {
                        await fileStreamCustomerBlob.CopyToAsync(innerFile);
                    }
                    ret = "CustomerGroup.zip";
                }
            }
            catch
            {
                ret = "fail";
            }

            return ret;
        }

    }
}
