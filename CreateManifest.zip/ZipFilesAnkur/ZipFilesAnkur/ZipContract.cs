﻿using System;
using System.Collections.Generic;
using System.Text;

namespace ZipFilesAnkur
{
    public class ZipContract
    {
        public string inputContainerName { get; set; }
        public string outputContainerName { get; set; }
        public string packageFileContainerName { get; set; }

        public string fileName { get; set; }
    }
}
