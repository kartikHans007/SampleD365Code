
using System.IO;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Azure.WebJobs.Host;
using Newtonsoft.Json;
using PgpCore;
using System;
using System.Text;
using Org.BouncyCastle.Bcpg.OpenPgp.FluentApi;

namespace DecryptFunctionV2
{
    public static class DecryptParameters
    {
        [FunctionName("DecryptParameters")]
        public static IActionResult Run([HttpTrigger(AuthorizationLevel.Anonymous, "get", "post", Route = null)]HttpRequest req, TraceWriter log)
        {

            log.Info("Decrypt text");

            string requestBody = new StreamReader(req.Body).ReadToEnd();
            var input = JsonConvert.DeserializeObject<DecryptDataParameters>(requestBody);

            string translatedText;
            if (input.isOpnePGP == "Yes")
            {
                translatedText = DecryptTextParametersOpenPGP(log, input);
            }
            else
            {
                translatedText = DecryptTextParameters(log, input);
            }

            return new OkObjectResult(translatedText);
        }

        public static string DecryptTextParameters(TraceWriter log, DecryptDataParameters input)
        {
            string encryptedString;

            try
            {
                using (PGP pgp = new PGP())
                {


                    string password = input.password;

                    string pkey = input.publicKey;

                    string prKey = input.privateKey;



                    byte[] toPublicEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(pkey);
                    String publicEncodedString = System.Convert.ToBase64String(toPublicEncodeAsBytes);
                    byte[] toPrivateEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(prKey);
                    String privateEncodedString = System.Convert.ToBase64String(toPrivateEncodeAsBytes);
                    using (Stream inputFileStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(input.toEncryptString)))
                    {
                        using (Stream publicKeyStream = new MemoryStream(Convert.FromBase64String(publicEncodedString)))
                        {
                            using (Stream privateKeyStream = new MemoryStream(Convert.FromBase64String(privateEncodedString)))
                            {
                                using (Stream encryptedMemoryStream = new MemoryStream())
                                {
                                    //pgp.EncryptStream(inputFileStream, encryptedMemoryStream, publicKeyStream);
                                    pgp.DecryptStreamAndVerify(inputFileStream, encryptedMemoryStream, publicKeyStream, privateKeyStream, password);
                                    // Reset stream to beginning
                                    encryptedMemoryStream.Seek(0, SeekOrigin.Begin);
                                    StreamReader encryptedReader = new StreamReader(encryptedMemoryStream);
                                    string encryptedText = encryptedReader.ReadToEnd();
                                    encryptedString = encryptedText;

                                }
                            }
                        }
                    }
                }
                return encryptedString;
            }
            catch
            {
                log.Info("failed");
                return "failed";
            }

        }



        public static string DecryptTextParametersOpenPGP(TraceWriter log, DecryptDataParameters input)
        {
            string decryptedText;
            try
            {
                
                string PlainMessage = input.toEncryptString;
                MemoryStream PlainMessageStream = new MemoryStream(Encoding.ASCII.GetBytes(PlainMessage));

                string strPublicKey1 = input.publicKey;
                Stream PublicKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPublicKey1));

                string strPrivateKey1 = input.privateKey;
                Stream PrivateKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPrivateKey1));

                string PassPhrase1 = input.password;

                var decryptionTask = new PgpDecryptionBuilder()
                    .Decrypt(PlainMessageStream)
                    .WithPrivateKey(PrivateKey1, PassPhrase1)
                    .VerifySignatureUsingKey(PublicKey1)
                    .Build();

                var decryptedStream = decryptionTask.Run().GetDecryptedStream();
                var signatureStatus = decryptionTask.GetSignatureStatus();

                if (signatureStatus == SignatureStatus.Valid || signatureStatus == SignatureStatus.NoSignature)
                {
                    decryptedText = new StreamReader(decryptedStream).ReadToEnd();
                }
                else
                {
                    decryptedText = "";
                }
                return decryptedText;

            }
            catch
            {
                log.Info("failed");
                return "failed";
            }
        }
    }
}
