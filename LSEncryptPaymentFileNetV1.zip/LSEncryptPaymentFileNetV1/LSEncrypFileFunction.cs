﻿using System;
using System.IO;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using PgpCore;
using Org.BouncyCastle.Bcpg.OpenPgp.FluentApi;

namespace LSEncryptPaymentFileNetV1
{
    public class LSEncrypFileFunction
    {
        public static string DecryptTextCorePGP(DecryptDataParameters input)
        {
            string encryptedString;

            try
            {
                using (PGP pgp = new PGP())
                {


                    string password = input.password;

                    string pkey = input.publicKey;

                    string prKey = input.privateKey;



                    byte[] toPublicEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(pkey);
                    String publicEncodedString = System.Convert.ToBase64String(toPublicEncodeAsBytes);
                    byte[] toPrivateEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(prKey);
                    String privateEncodedString = System.Convert.ToBase64String(toPrivateEncodeAsBytes);
                    using (Stream inputFileStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(input.toEncryptString)))
                    {
                        using (Stream publicKeyStream = new MemoryStream(Convert.FromBase64String(publicEncodedString)))
                        {
                            using (Stream privateKeyStream = new MemoryStream(Convert.FromBase64String(privateEncodedString)))
                            {
                                using (Stream encryptedMemoryStream = new MemoryStream())
                                {
                                    //pgp.EncryptStream(inputFileStream, encryptedMemoryStream, publicKeyStream);
                                    pgp.DecryptStreamAndVerify(inputFileStream, encryptedMemoryStream, publicKeyStream, privateKeyStream, password);
                                    // Reset stream to beginning
                                    encryptedMemoryStream.Seek(0, SeekOrigin.Begin);
                                    StreamReader encryptedReader = new StreamReader(encryptedMemoryStream);
                                    string encryptedText = encryptedReader.ReadToEnd();
                                    encryptedString = encryptedText;

                                }
                            }
                        }
                    }
                }
                return encryptedString;
            }
            catch
            {
                return "failed";
            }

        }



        public static string DecryptTextOpenPGP(DecryptDataParameters input)
        {
            string decryptedText;
            try
            {

                string PlainMessage = input.toEncryptString;
                MemoryStream PlainMessageStream = new MemoryStream(Encoding.ASCII.GetBytes(PlainMessage));

                string strPublicKey1 = input.publicKey;
                Stream PublicKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPublicKey1));

                string strPrivateKey1 = input.privateKey;
                Stream PrivateKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPrivateKey1));

                string PassPhrase1 = input.password;

                var decryptionTask = new PgpDecryptionBuilder()
                    .Decrypt(PlainMessageStream)
                    .WithPrivateKey(PrivateKey1, PassPhrase1)
                    .VerifySignatureUsingKey(PublicKey1)
                    .Build();

                var decryptedStream = decryptionTask.Run().GetDecryptedStream();
                var signatureStatus = decryptionTask.GetSignatureStatus();

                if (signatureStatus == SignatureStatus.Valid || signatureStatus == SignatureStatus.NoSignature)
                {
                    decryptedText = new StreamReader(decryptedStream).ReadToEnd();
                }
                else
                {
                    decryptedText = "";
                }
                return decryptedText;

            }
            catch
            {
                return "failed";
            }
        }
        public static string EncryptTextCorePGP(LSEncryptFileParameters input)
        {
            string encryptedString;

            try
            {
                using (PGP pgp = new PGP())
                {
                    string password = input.password;

                    string pkey = input.publicKey;

                    string prKey = input.privateKey;

                    byte[] toPublicEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(pkey);
                    String publicEncodedString = System.Convert.ToBase64String(toPublicEncodeAsBytes);
                    byte[] toPrivateEncodeAsBytes = System.Text.ASCIIEncoding.ASCII.GetBytes(prKey);
                    String privateEncodedString = System.Convert.ToBase64String(toPrivateEncodeAsBytes);
                    using (Stream inputFileStream = new MemoryStream(System.Text.Encoding.UTF8.GetBytes(input.toEncryptString)))
                    {
                        using (Stream publicKeyStream = new MemoryStream(Convert.FromBase64String(publicEncodedString)))
                        {
                            using (Stream privateKeyStream = new MemoryStream(Convert.FromBase64String(privateEncodedString)))
                            {
                                using (Stream encryptedMemoryStream = new MemoryStream())
                                {
                                    //pgp.EncryptStream(inputFileStream, encryptedMemoryStream, publicKeyStream);
                                    pgp.EncryptStreamAndSign(inputFileStream, encryptedMemoryStream, publicKeyStream, privateKeyStream, password);
                                    // Reset stream to beginning
                                    encryptedMemoryStream.Seek(0, SeekOrigin.Begin);
                                    StreamReader encryptedReader = new StreamReader(encryptedMemoryStream);
                                    string encryptedText = encryptedReader.ReadToEnd();
                                    encryptedString = encryptedText;

                                }
                            }
                        }
                    }
                }
                return encryptedString;
            }
            catch
            {
                return "failed";
            }

        }


        // 
        public static string EncryptTextOpenPGP(LSEncryptFileParameters input)
        {
            try
            {
                string PlainMessage = input.toEncryptString;
                MemoryStream PlainMessageStream = new MemoryStream(Encoding.ASCII.GetBytes(PlainMessage));

                string strPublicKey1 = input.publicKey;
                Stream PublicKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPublicKey1));

                string strPrivateKey1 = input.privateKey;
                Stream PrivateKey1 = new MemoryStream(Encoding.ASCII.GetBytes(strPrivateKey1));

                string PassPhrase1 = input.password;

                var encryptionTask = new PgpEncryptionBuilder()
                    .Encrypt(PlainMessageStream)
                    .WithArmor()
                    .WithCompression()
                    .WithIntegrityCheck()
                    .WithPublicKey(PublicKey1)
                    .WithSigning(PrivateKey1, PassPhrase1)
                    .Build();

                var encryptedStream = encryptionTask.Run().GetEncryptedStream();

                var encryptedText = new StreamReader(encryptedStream).ReadToEnd();

                return encryptedText;
            }
            catch
            {

                return "failed";
            }
        }
    }
}
