﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LSEncryptPaymentFileNetV1
{
    public class LSEncryptFileParameters
    {
        public string toEncryptString { get; set; }
        public string publicKey { get; set; }
        public string privateKey { get; set; }
        public string password { get; set; }
        public string isOpnePGP { get; set; }
    }
}
